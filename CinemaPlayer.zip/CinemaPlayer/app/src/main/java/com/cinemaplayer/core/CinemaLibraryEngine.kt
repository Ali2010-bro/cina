package com.cinemaplayer.core

// Pure Kotlin (no Android deps): unit-testable, fast, single pass over the playlist.

enum class Kind { MOVIE, EPISODE, LIVE, UNKNOWN }

data class RawEntry(
    val name: String,
    val url: String,
    val group: String?,
    val tvgName: String?,
    val logo: String?,
    val tvgId: String?
)

data class ParseResult(val entries: List<RawEntry>, val skippedLines: Int, val errors: List<String>)

/* ---------------------------- 1. PARSER ---------------------------- */

object M3uParser {
    private val attrRegex = Regex("""([\w-]+)="([^"]*)"""")

    fun parse(lines: Sequence<String>): ParseResult {
        val out = ArrayList<RawEntry>()
        val errors = ArrayList<String>()
        var skipped = 0
        var pendingInf: String? = null
        var pendingGroup: String? = null
        var lineNo = 0

        for (raw in lines) {
            lineNo++
            val line = raw.trim().removePrefix("\uFEFF")
            if (line.isEmpty() || line.startsWith("#EXTM3U")) continue
            when {
                line.startsWith("#EXTINF") -> {
                    if (pendingInf != null) { skipped++; errors += "Line $lineNo: EXTINF without URL" }
                    pendingInf = line; pendingGroup = null
                }
                line.startsWith("#EXTGRP:") -> pendingGroup = line.substringAfter(':').trim()
                line.startsWith("#") -> Unit // EXTVLCOPT etc.
                else -> {
                    if (!looksLikeUrl(line)) { skipped++; errors += "Line $lineNo: invalid URL"; pendingInf = null; continue }
                    val inf = pendingInf
                    out += if (inf != null) buildEntry(inf, line, pendingGroup)
                    else RawEntry(line.substringAfterLast('/').substringBeforeLast('.'), line, null, null, null, null)
                    pendingInf = null; pendingGroup = null
                }
            }
        }
        if (pendingInf != null) { skipped++; errors += "Trailing EXTINF without URL" }
        return ParseResult(out, skipped, errors)
    }

    private fun looksLikeUrl(s: String) =
        s.startsWith("http://", true) || s.startsWith("https://", true) ||
            s.startsWith("rtmp", true) || s.startsWith("rtsp", true) || s.startsWith("udp", true)

    private fun buildEntry(inf: String, url: String, extGrp: String?): RawEntry {
        val header = inf.removePrefix("#EXTINF:")
        val attrs = attrRegex.findAll(header).associate { it.groupValues[1].lowercase() to it.groupValues[2] }
        val searchFrom = attrRegex.findAll(header).lastOrNull()?.range?.last?.plus(1) ?: 0
        val comma = header.indexOf(',', searchFrom)
        val title = (if (comma >= 0) header.substring(comma + 1) else "").trim()
        val name = title.ifBlank { attrs["tvg-name"].orEmpty() }.ifBlank { url.substringAfterLast('/') }
        return RawEntry(
            name = name,
            url = url,
            group = attrs["group-title"]?.ifBlank { null } ?: extGrp,
            tvgName = attrs["tvg-name"]?.ifBlank { null },
            logo = attrs["tvg-logo"]?.ifBlank { null },   // real logo only; never fabricated
            tvgId = attrs["tvg-id"]?.ifBlank { null }
        )
    }
}

/* ------------------------- 2. CLASSIFIER -------------------------- */

data class EpisodeInfo(val season: Int, val episode: Int, val seriesTitle: String)

data class Classified(
    val raw: RawEntry,
    val kind: Kind,
    val title: String,            // cleaned display title
    val year: Int?,
    val language: String?,        // derived from category text only
    val genre: String?,           // derived from category text only
    val episode: EpisodeInfo?
)

object ContentClassifier {
    private val liveGroup = Regex(
        "live|sport|football|soccer|bein|news|relig|quran|islam|radio|music|weather|24/7|channels?|" +
            "رياضة|رياضه|كرة|اخبار|أخبار|قرآن|قران|ديني|اذاعة|إذاعة|موسيقى|طقس|قنوات|بث مباشر",
        RegexOption.IGNORE_CASE
    )
    private val vodGroup = Regex(
        "movie|film|vod|series|serie|season|episode|dizi|anime|drama|kdrama|" +
            "افلام|أفلام|فيلم|مسلسل|مسلسلات|حلقات|موسم",
        RegexOption.IGNORE_CASE
    )
    private val vodExt = Regex("""\.(mp4|mkv|avi|mov|wmv|flv|webm|m4v)(\?|$)""", RegexOption.IGNORE_CASE)
    private val yearRx = Regex("""[(\[]\s*((?:19|20)\d{2})\s*[)\]]""")

    // Episode patterns, most specific first.
    private val sxe = Regex("""\bS(\d{1,2})\s*[ ._-]?E(\d{1,4})\b""", RegexOption.IGNORE_CASE)
    private val nxn = Regex("""\b(\d{1,2})x(\d{2,3})\b""", RegexOption.IGNORE_CASE)
    private val seasonRx = Regex("""(?:\bseason|\bsaison|\bsezon|الموسم|موسم)\s*[:.]?\s*(\d{1,2})""", RegexOption.IGNORE_CASE)
    private val epRx = Regex("""(?:\bepisode|\bep\b|\bbolum|\bbölüm|الحلقة|حلقة)\s*[:.]?\s*(\d{1,4})""", RegexOption.IGNORE_CASE)

    private val languages = listOf(
        "Arabic" to Regex("arab|عربي|عربية|مصري|خليجي|سوري", RegexOption.IGNORE_CASE),
        "Turkish" to Regex("turk|türk|dizi|تركي|تركية", RegexOption.IGNORE_CASE),
        "Indian" to Regex("indian|hindi|bollywood|tamil|telugu|هندي|هندية", RegexOption.IGNORE_CASE),
        "Korean" to Regex("korea|kdrama|k-drama|كوري|كورية", RegexOption.IGNORE_CASE),
        "Anime" to Regex("anime|انمي|أنمي", RegexOption.IGNORE_CASE),
        "Foreign" to Regex("foreign|english|american|hollywood|اجنبي|أجنبي|اجنبية", RegexOption.IGNORE_CASE)
    )
    private val genres = listOf(
        "Action" to Regex("action|اكشن|أكشن", RegexOption.IGNORE_CASE),
        "Comedy" to Regex("comed|كوميد", RegexOption.IGNORE_CASE),
        "Drama" to Regex("drama|دراما", RegexOption.IGNORE_CASE),
        "Horror" to Regex("horror|رعب", RegexOption.IGNORE_CASE),
        "Romance" to Regex("romanc|رومانس", RegexOption.IGNORE_CASE),
        "Animation" to Regex("animat|cartoon|كرتون|انيميشن|أنيميشن", RegexOption.IGNORE_CASE)
    )

    fun classify(e: RawEntry): Classified {
        val group = e.group.orEmpty()
        val url = e.url
        val lower = url.lowercase()
        val episode = parseEpisode(e.name)

        var vod = 0
        var live = 0

        // URL signals (Xtream Codes layout is the most reliable)
        if ("/movie/" in lower) vod += 5
        if ("/series/" in lower) vod += 5
        if ("/live/" in lower) live += 5
        if (vodExt.containsMatchIn(lower)) vod += 3
        // Bare .ts streams are almost always live; .m3u8 is deliberately neutral.
        if (Regex("""\.ts(\?|$)""").containsMatchIn(lower) && vod < 5) live += 2

        // Category signals
        if (liveGroup.containsMatchIn(group)) live += 4
        if (vodGroup.containsMatchIn(group)) vod += 3

        // Name signals
        if (episode != null) vod += 4
        if (yearRx.containsMatchIn(e.name)) vod += 2
        if (liveGroup.containsMatchIn(e.name) && episode == null) live += 2
        if (e.tvgId != null && vod < 3 && episode == null) live += 1 // EPG ids typically mark channels

        val score = vod - live
        val kind = when {
            live >= 4 && vod < 5 -> Kind.LIVE              // explicit live category wins unless Xtream VOD URL
            score >= 3 && episode != null -> Kind.EPISODE
            score >= 3 -> Kind.MOVIE
            score <= -1 -> Kind.LIVE
            else -> Kind.UNKNOWN                            // ambiguous: excluded from library by default
        }

        val year = yearRx.find(e.name)?.groupValues?.get(1)?.toInt()
        val ctx = "$group ${e.name}"
        return Classified(
            raw = e,
            kind = kind,
            title = cleanTitle(episode?.seriesTitle ?: e.name),
            year = year,
            language = languages.firstOrNull { it.second.containsMatchIn(ctx) }?.first,
            genre = genres.firstOrNull { it.second.containsMatchIn(ctx) }?.first,
            episode = episode
        )
    }

    fun parseEpisode(name: String): EpisodeInfo? {
        var season: Int? = null
        var ep: Int? = null
        var title = name
        (sxe.find(name) ?: nxn.find(name))?.let {
            season = it.groupValues[1].toInt(); ep = it.groupValues[2].toInt()
            title = name.removeRange(it.range)
        } ?: run {
            val s = seasonRx.find(name)
            val e = epRx.find(name)
            if (e != null) {
                season = s?.groupValues?.get(1)?.toInt() ?: 1
                ep = e.groupValues[1].toInt()
                title = name
                listOfNotNull(s?.range, e.range).sortedByDescending { it.first }.forEach { title = title.removeRange(it) }
            }
        }
        val s = season ?: return null
        val e = ep ?: return null
        return EpisodeInfo(s, e, cleanTitle(title))
    }

    private fun cleanTitle(t: String) =
        t.replace(yearRx, " ")
            .replace(Regex("""\b(4k|uhd|fhd|hd|sd|1080p|720p|480p|x264|x265|hevc)\b""", RegexOption.IGNORE_CASE), " ")
            .replace(Regex("""^[\s|:\-–_.]+|[\s|:\-–_.]+$"""), "")
            .replace(Regex("""\s{2,}"""), " ")
            .trim()
}

/* ------------------------- 3. LIBRARY BUILDER ------------------------ */

data class Movie(
    val id: String, val title: String, val year: Int?, val language: String?, val genre: String?,
    val logo: String?, val url: String, val alternateUrls: List<String>, val group: String?
)
data class Episode(val id: String, val season: Int, val number: Int, val url: String, val alternateUrls: List<String>)
data class Series(
    val id: String, val title: String, val language: String?, val genre: String?, val logo: String?,
    val seasons: Map<Int, List<Episode>>           // sorted by season, episodes sorted by number
)
data class Library(val movies: List<Movie>, val series: List<Series>, val excludedCount: Int)

object LibraryBuilder {
    private fun key(title: String) =
        title.lowercase().replace(Regex("""[^\p{L}\p{N}]+"""), " ").trim()

    fun build(parsed: ParseResult): Library {
        val classified = parsed.entries.map(ContentClassifier::classify)
        val vod = classified.filter { it.kind == Kind.MOVIE || it.kind == Kind.EPISODE }

        // Movies: dedupe by normalized title + year; original URLs are preserved as alternates.
        val movies = vod.filter { it.kind == Kind.MOVIE }
            .groupBy { key(it.title) + "|" + (it.year ?: "") }
            .map { (k, list) ->
                val first = list.first()
                Movie(
                    id = k.hashCode().toString(), title = first.title, year = first.year,
                    language = list.firstNotNullOfOrNull { it.language },
                    genre = list.firstNotNullOfOrNull { it.genre },
                    logo = list.firstNotNullOfOrNull { it.raw.logo },
                    url = first.raw.url,
                    alternateUrls = list.drop(1).map { it.raw.url }.distinct() - first.raw.url,
                    group = first.raw.group
                )
            }.sortedBy { it.title.lowercase() }

        // Series -> Seasons -> Episodes (dedupe identical season/episode pairs).
        val series = vod.filter { it.kind == Kind.EPISODE && it.episode != null }
            .groupBy { key(it.episode!!.seriesTitle) }
            .filterKeys { it.isNotBlank() }
            .map { (k, list) ->
                val seasons = list.groupBy { it.episode!!.season }.toSortedMap().mapValues { (_, eps) ->
                    eps.groupBy { it.episode!!.episode }.toSortedMap().map { (n, dup) ->
                        Episode(
                            id = (k + dup.first().episode!!.season + "x" + n).hashCode().toString(),
                            season = dup.first().episode!!.season, number = n,
                            url = dup.first().raw.url,
                            alternateUrls = dup.drop(1).map { it.raw.url }.distinct()
                        )
                    }
                }
                Series(
                    id = k.hashCode().toString(), title = list.first().episode!!.seriesTitle,
                    language = list.firstNotNullOfOrNull { it.language },
                    genre = list.firstNotNullOfOrNull { it.genre },
                    logo = list.firstNotNullOfOrNull { it.raw.logo },
                    seasons = seasons
                )
            }.sortedBy { it.title.lowercase() }

        return Library(movies, series, excludedCount = classified.size - vod.size)
    }
}

/** Next-episode lookup for auto-play. Returns null at the end of the series. */
fun Series.nextAfter(season: Int, episode: Int): Episode? {
    seasons[season]?.firstOrNull { it.number > episode }?.let { return it }
    return seasons.keys.sorted().firstOrNull { it > season }?.let { seasons[it]?.firstOrNull() }
}

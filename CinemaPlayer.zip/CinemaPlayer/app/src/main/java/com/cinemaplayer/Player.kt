package com.cinemaplayer

import android.app.Activity
import android.content.pm.ActivityInfo
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay

@Composable
fun PlayerScreen(vm: VM, p: Screen.Play) {
    val ctx = LocalContext.current
    var err by remember(p.id) { mutableStateOf<String?>(null) }
    val player = remember(p.id) {
        // Hardware MediaCodec first, software decoder fallback enabled; HLS/progressive auto-detected.
        ExoPlayer.Builder(ctx, DefaultRenderersFactory(ctx).setEnableDecoderFallback(true)).build().apply {
            setMediaItem(MediaItem.fromUri(p.url)); seekTo(vm.store.pos(p.id)); prepare(); playWhenReady = true
        }
    }
    DisposableEffect(p.id) {
        val act = ctx as Activity
        act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        val l = object : Player.Listener {
            override fun onPlayerError(e: PlaybackException) { err = "Playback error: ${e.errorCodeName}. Check your connection or the stream." }
            override fun onPlaybackStateChanged(s: Int) {
                if (s == Player.STATE_ENDED) { vm.store.setPos(p.id, 0); vm.next(p) }
            }
        }
        player.addListener(l)
        onDispose {
            if (player.playbackState != Player.STATE_ENDED) vm.store.setPos(p.id, player.currentPosition)
            player.release(); act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }
    LaunchedEffect(p.id) { while (true) { delay(5000); vm.store.setPos(p.id, player.currentPosition) } }
    BackHandler { vm.screen = p.back }
    Box(Modifier.fillMaxSize()) {
        // Default controller already offers speed, audio-track and subtitle selection.
        AndroidView({ PlayerView(it).apply { this.player = player } }, Modifier.fillMaxSize())
        err?.let {
            Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(it)
                Button(onClick = { err = null; player.prepare() }) { Text("Retry") }
            }
        }
    }
}

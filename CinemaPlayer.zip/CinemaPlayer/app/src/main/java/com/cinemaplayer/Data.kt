package com.cinemaplayer

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.cinemaplayer.core.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class Playlist(val name: String, val url: String)

sealed interface Screen {
    object Home : Screen
    object Settings : Screen
    data class Detail(val m: Movie) : Screen
    data class SeriesD(val s: Series) : Screen
    data class Play(val title: String, val url: String, val id: String, val back: Screen,
                    val series: Series?, val season: Int, val ep: Int) : Screen
}

/** Lightweight persistence (SharedPreferences): playlists, favorites, history, positions. */
class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("cp", 0)
    fun playlists(): List<Playlist> = runCatching {
        val a = JSONArray(p.getString("pl", "[]"))
        (0 until a.length()).map { a.getJSONObject(it).let { o -> Playlist(o.getString("n"), o.getString("u")) } }
    }.getOrDefault(emptyList())
    fun savePlaylists(l: List<Playlist>) =
        p.edit().putString("pl", JSONArray(l.map { JSONObject().put("n", it.name).put("u", it.url) }).toString()).apply()
    var last: String? get() = p.getString("last", null); set(v) { p.edit().putString("last", v).apply() }
    fun favs(): Set<String> = p.getStringSet("fav", emptySet())!!.toSet()
    fun setFavs(s: Set<String>) = p.edit().putStringSet("fav", s).apply()
    fun pos(id: String) = p.getLong("pos_$id", 0L)
    fun setPos(id: String, v: Long) = p.edit().putLong("pos_$id", v).apply()
    fun history(): List<String> = p.getString("hist", "")!!.split("|").filter { it.isNotEmpty() }
    fun touch(id: String) = p.edit().putString("hist", (listOf(id) + history() - id).take(30).joinToString("|")).apply()
    fun lastEp(sid: String): String? = p.getString("ep_$sid", null)
    fun setLastEp(sid: String, v: String) = p.edit().putString("ep_$sid", v).apply()
}

class VM(app: Application) : AndroidViewModel(app) {
    val store = Store(app)
    var lib by mutableStateOf(Library(emptyList(), emptyList(), 0))
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var playlists by mutableStateOf(store.playlists())
    var favs by mutableStateOf(store.favs())
    var history by mutableStateOf(store.history())
    var screen by mutableStateOf<Screen>(Screen.Home)

    init { playlists.firstOrNull { it.url == store.last }?.let { open(it) } }

    fun add(name: String, url: String) {
        val p = Playlist(name.ifBlank { "Playlist" }, url.trim())
        playlists = playlists.filter { it.url != p.url } + p
        store.savePlaylists(playlists); open(p)
    }
    fun addXtream(host: String, user: String, pass: String) {
        val h = host.trim().trimEnd('/').let { if (it.startsWith("http")) it else "http://$it" }
        add(user.trim() + "@" + Uri.parse(h).host,
            "$h/get.php?username=${Uri.encode(user.trim())}&password=${Uri.encode(pass.trim())}&type=m3u_plus&output=m3u8")
    }
    fun remove(p: Playlist) {
        playlists = playlists - p; store.savePlaylists(playlists)
        if (store.last == p.url) { store.last = null; lib = Library(emptyList(), emptyList(), 0) }
    }
    fun open(p: Playlist) {
        store.last = p.url; loading = true; error = null
        viewModelScope.launch {
            try {
                lib = withContext(Dispatchers.IO) { load(p.url) }
                screen = Screen.Home
                if (lib.movies.isEmpty() && lib.series.isEmpty())
                    error = "No movies or series found. ${lib.excludedCount} entries were excluded as live TV or unclassifiable."
            } catch (e: Exception) { error = "Could not load playlist: ${e.message}" }
            finally { loading = false }
        }
    }
    private fun load(url: String): Library {
        val ctx = getApplication<Application>()
        val stream = if (url.startsWith("content:")) ctx.contentResolver.openInputStream(Uri.parse(url))
            ?: error("Cannot open file")
        else (URL(url).openConnection() as HttpURLConnection).run {
            connectTimeout = 15000; readTimeout = 60000
            if (responseCode !in 200..299) error("Server returned HTTP $responseCode")
            inputStream
        }
        val parsed = stream.bufferedReader().useLines { M3uParser.parse(it) }
        return LibraryBuilder.build(parsed)
    }
    fun toggleFav(id: String) { favs = if (id in favs) favs - id else favs + id; store.setFavs(favs) }
    fun play(title: String, url: String, id: String, histId: String, back: Screen,
             series: Series? = null, season: Int = 0, ep: Int = 0) {
        store.touch(histId); history = store.history()
        if (series != null) store.setLastEp(series.id, "$season:$ep")
        screen = Screen.Play(title, url, id, back, series, season, ep)
    }
    fun next(p: Screen.Play) {
        val s = p.series; val n = s?.nextAfter(p.season, p.ep)
        if (s != null && n != null) play("${s.title} S${n.season}E${n.number}", n.url, n.id, s.id, p.back, s, n.season, n.number)
        else screen = p.back
    }
}

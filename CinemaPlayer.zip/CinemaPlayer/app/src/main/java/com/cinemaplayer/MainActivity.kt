package com.cinemaplayer

import android.app.PictureInPictureParams
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels

class MainActivity : ComponentActivity() {
    private val vm: VM by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CinemaTheme { Root(vm) } }
    }
    override fun onUserLeaveHint() {
        if (vm.screen is Screen.Play && Build.VERSION.SDK_INT >= 26)
            enterPictureInPictureMode(PictureInPictureParams.Builder().build())
    }
}

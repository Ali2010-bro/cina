package com.cinemaplayer

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.cinemaplayer.core.*

val Gold = Color(0xFFD4A24C)
val Bg = Color(0xFF0B0B0F)

@Composable
fun CinemaTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(primary = Gold, onPrimary = Color.Black, background = Bg, surface = Color(0xFF16161C))
) { Surface(Modifier.fillMaxSize(), color = Bg, content = content) }

@Composable
fun Root(vm: VM) {
    val s = vm.screen
    val empty = vm.lib.movies.isEmpty() && vm.lib.series.isEmpty()
    when {
        vm.loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = Gold) }
        s is Screen.Play -> PlayerScreen(vm, s)
        s is Screen.Settings || empty -> SettingsScreen(vm, canClose = !empty)
        s is Screen.Detail -> MovieScreen(vm, s.m)
        s is Screen.SeriesD -> SeriesScreen(vm, s.s)
        else -> HomeScreen(vm)
    }
}

class Tile(val id: String, val title: String, val logo: String?, val open: () -> Unit)

@Composable
fun Poster(t: Tile, w: Int = 120) {
    Column(Modifier.width(w.dp).clickable(onClick = t.open)) {
        Box(Modifier.size(w.dp, (w * 1.5f).dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF22222B))) {
            if (t.logo != null) AsyncImage(t.logo, t.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else Text(t.title, Modifier.align(Alignment.Center).padding(8.dp), textAlign = TextAlign.Center, fontSize = 12.sp)
        }
        Text(t.title, Modifier.padding(top = 4.dp), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp)
    }
}

@Composable
fun Shelf(title: String, tiles: List<Tile>) {
    if (tiles.isEmpty()) return
    Text(title, Modifier.padding(16.dp, 16.dp, 16.dp, 8.dp), fontSize = 18.sp, color = Gold)
    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        items(tiles) { Poster(it) }
    }
}

@Composable
fun HomeScreen(vm: VM) {
    var q by remember { mutableStateOf("") }
    var tab by remember { mutableIntStateOf(0) }
    var lang by remember { mutableStateOf<String?>(null) }
    val lib = vm.lib
    val langs = remember(lib) { (lib.movies.mapNotNull { it.language } + lib.series.mapNotNull { it.language }).distinct() }
    val ql = q.trim().lowercase()
    val ms = remember(lib, ql, lang) {
        lib.movies.filter { (lang == null || it.language == lang) && (ql.isEmpty() || ql in it.title.lowercase() || ql in it.group.orEmpty().lowercase()) }
    }
    val ss = remember(lib, ql, lang) {
        lib.series.filter { (lang == null || it.language == lang) && (ql.isEmpty() || ql in it.title.lowercase()) }
    }
    fun mt(m: Movie) = Tile(m.id, m.title, m.logo) { vm.screen = Screen.Detail(m) }
    fun st(s: Series) = Tile(s.id, s.title, s.logo) { vm.screen = Screen.SeriesD(s) }
    val cont = vm.history.mapNotNull { id ->
        lib.movies.firstOrNull { it.id == id }?.let { mt(it) } ?: lib.series.firstOrNull { it.id == id }?.let { st(it) }
    }
    val fav = lib.movies.filter { it.id in vm.favs }.map { mt(it) } + lib.series.filter { it.id in vm.favs }.map { st(it) }
    val featured = if (ql.isEmpty() && tab == 0) lib.movies.firstOrNull { it.logo != null } else null

    LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(16.dp, 12.dp, 8.dp, 0.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("CINEMA", Modifier.weight(1f), fontSize = 22.sp, color = Gold)
                IconButton({ vm.screen = Screen.Settings }) { Icon(Icons.Default.Settings, "Settings") }
            }
        }
        item {
            OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(16.dp, 4.dp), singleLine = true,
                placeholder = { Text("Search title or category") }, leadingIcon = { Icon(Icons.Default.Search, null) })
        }
        item {
            LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(listOf("All", "Movies", "Series", "Favorites")) { t ->
                    val i = listOf("All", "Movies", "Series", "Favorites").indexOf(t)
                    FilterChip(tab == i, { tab = i }, { Text(t) })
                }
                items(langs) { l -> FilterChip(lang == l, { lang = if (lang == l) null else l }, { Text(l) }) }
            }
        }
        featured?.let { f ->
            item {
                Box(Modifier.fillMaxWidth().height(240.dp).padding(16.dp).clip(RoundedCornerShape(16.dp)).clickable { vm.screen = Screen.Detail(f) }) {
                    AsyncImage(f.logo, f.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Bg))))
                    Text(f.title, Modifier.align(Alignment.BottomStart).padding(12.dp), fontSize = 22.sp)
                }
            }
        }
        item {
            if (tab == 0 && ql.isEmpty()) Shelf("Continue Watching", cont)
            if (tab == 3) Shelf("Favorites", fav)
            if (tab == 0 || tab == 1) Shelf("Movies", ms.map { mt(it) })
            if (tab == 0 || tab == 2) Shelf("Series", ss.map { st(it) })
            if (tab == 0 && ql.isEmpty()) Shelf("Favorites", fav)
        }
    }
}

@Composable
fun MovieScreen(vm: VM, m: Movie) {
    BackHandler { vm.screen = Screen.Home }
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Poster(Tile(m.id, m.title, m.logo) {}, 200)
        Text(m.title, fontSize = 26.sp)
        val meta = listOfNotNull(m.year?.toString(), m.genre, m.language).joinToString(" • ")
        if (meta.isNotEmpty()) Text(meta, color = Color.Gray)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ vm.play(m.title, m.url, m.id, m.id, Screen.Detail(m)) }) {
                Icon(Icons.Default.PlayArrow, null)
                Text(if (vm.store.pos(m.id) > 0) "Resume" else "Play")
            }
            OutlinedButton({ vm.toggleFav(m.id) }) {
                Icon(if (m.id in vm.favs) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null)
                Text("Favorite")
            }
        }
    }
}

@Composable
fun SeriesScreen(vm: VM, s: Series) {
    BackHandler { vm.screen = Screen.Home }
    var season by remember { mutableIntStateOf(s.seasons.keys.first()) }
    val resume = vm.store.lastEp(s.id)?.split(":")?.let { it[0].toInt() to it[1].toInt() }
    fun playEp(e: Episode) = vm.play("${s.title} S${e.season}E${e.number}", e.url, e.id, s.id, Screen.SeriesD(s), s, e.season, e.number)
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Poster(Tile(s.id, s.title, s.logo) {}, 160); Text(s.title, fontSize = 26.sp) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                resume?.let { (rs, re) ->
                    s.seasons[rs]?.firstOrNull { it.number == re }?.let { e ->
                        Button({ playEp(e) }) { Icon(Icons.Default.PlayArrow, null); Text("Resume S${rs}E$re") }
                    }
                }
                OutlinedButton({ vm.toggleFav(s.id) }) {
                    Icon(if (s.id in vm.favs) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null); Text("Favorite")
                }
            }
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(s.seasons.keys.toList()) { n -> FilterChip(season == n, { season = n }, { Text("Season $n") }) }
            }
        }
        items(s.seasons[season].orEmpty()) { e ->
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color(0xFF16161C)).clickable { playEp(e) }.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Text("Episode ${e.number}", Modifier.weight(1f))
                if (vm.store.pos(e.id) > 0) Text("in progress", color = Gold, fontSize = 12.sp)
                Icon(Icons.Default.PlayArrow, null)
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: VM, canClose: Boolean) {
    val ctx = LocalContext.current
    BackHandler(canClose) { vm.screen = Screen.Home }
    var mode by remember { mutableIntStateOf(0) }
    var url by remember { mutableStateOf("") }
    var host by remember { mutableStateOf("") }
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            runCatching { ctx.contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            vm.add(it.lastPathSegment ?: "Local file", it.toString())
        }
    }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("CINEMA PLAYER", fontSize = 24.sp, color = Gold) }
        vm.error?.let { e -> item { Text(e, color = MaterialTheme.colorScheme.error) } }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("URL", "File", "Xtream").forEachIndexed { i, t -> FilterChip(mode == i, { mode = i }, { Text(t) }) }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                when (mode) {
                    0 -> { OutlinedTextField(url, { url = it }, Modifier.fillMaxWidth(), label = { Text("M3U / M3U8 URL") }, singleLine = true)
                        Button({ vm.add(runCatching { java.net.URI(url).host }.getOrNull() ?: "Playlist", url) }, enabled = url.isNotBlank()) { Text("IMPORT") } }
                    1 -> Button({ picker.launch(arrayOf("*/*")) }) { Text("Choose .m3u / .m3u8 file") }
                    else -> { OutlinedTextField(host, { host = it }, Modifier.fillMaxWidth(), label = { Text("Server URL") }, singleLine = true)
                        OutlinedTextField(user, { user = it }, Modifier.fillMaxWidth(), label = { Text("Username") }, singleLine = true)
                        OutlinedTextField(pass, { pass = it }, Modifier.fillMaxWidth(), label = { Text("Password") }, singleLine = true)
                        Button({ vm.addXtream(host, user, pass) }, enabled = host.isNotBlank() && user.isNotBlank()) { Text("LOGIN & IMPORT") } }
                }
            }
        }
        item { Text("Playlists", color = Gold) }
        items(vm.playlists) { p ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(p.name, Modifier.weight(1f).clickable { vm.open(p) }, maxLines = 1, overflow = TextOverflow.Ellipsis)
                IconButton({ vm.open(p) }) { Icon(Icons.Default.Refresh, "Refresh") }
                IconButton({ vm.remove(p) }) { Icon(Icons.Default.Delete, "Delete") }
            }
        }
        if (canClose) item { TextButton({ vm.screen = Screen.Home }) { Text("Back") } }
    }
}
